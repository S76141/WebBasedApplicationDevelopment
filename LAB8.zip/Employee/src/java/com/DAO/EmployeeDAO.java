package com.DAO;

import java.sql.*;
import java.util.*;
import com.Model.Employee;

public class EmployeeDAO {

    private String jdbcURL      = "jdbc:mysql://localhost:3306/Company";
    private String jdbcUsername = "root";
    private String jdbcPassword = "admin";

    private static final String INSERT_SQL =
        "INSERT INTO employees (Name, Email, Position) VALUES (?,?,?)";
    private static final String SELECT_ALL_SQL =
        "SELECT * FROM employees";
    private static final String SELECT_BY_ID_SQL =
        "SELECT * FROM employees WHERE id = ?";
    private static final String UPDATE_SQL =
        "UPDATE employees SET Name=?, Email=?, Position=? WHERE id=?";
    private static final String DELETE_SQL =
        "DELETE FROM employees WHERE id=?";

    protected Connection getConnection() {
        Connection conn = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return conn;
    }

    public void insertEmployee(Employee emp) throws SQLException {
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(INSERT_SQL)) {
            ps.setString(1, emp.getName());
            ps.setString(2, emp.getEmail());
            ps.setString(3, emp.getPosition());
            ps.executeUpdate();
        }
    }

    public List<Employee> selectAllEmployees() {
        List<Employee> list = new ArrayList<>();
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(SELECT_ALL_SQL)) {
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Employee(
                    rs.getInt("id"),
                    rs.getString("Name"),
                    rs.getString("Email"),
                    rs.getString("Position")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public Employee selectEmployee(int id) {
        Employee emp = null;
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(SELECT_BY_ID_SQL)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                emp = new Employee(
                    rs.getInt("id"),
                    rs.getString("Name"),
                    rs.getString("Email"),
                    rs.getString("Position")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return emp;
    }

    public boolean updateEmployee(Employee emp) throws SQLException {
        boolean updated;
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(UPDATE_SQL)) {
            ps.setString(1, emp.getName());
            ps.setString(2, emp.getEmail());
            ps.setString(3, emp.getPosition());
            ps.setInt(4, emp.getId());
            updated = ps.executeUpdate() > 0;
        }
        return updated;
    }

    public boolean deleteEmployee(int id) throws SQLException {
        boolean deleted;
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(DELETE_SQL)) {
            ps.setInt(1, id);
            deleted = ps.executeUpdate() > 0;
        }
        return deleted;
    }
}