package com.WEB;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import com.DAO.EmployeeDAO;
import com.Model.Employee;

@WebServlet(urlPatterns = {"/list", "/new", "/insert", "/edit", "/update", "/delete"})
public class EmployeeServlet extends HttpServlet {

    private EmployeeDAO employeeDAO;

    public void init() {
        employeeDAO = new EmployeeDAO();
    }

    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        doGet(req, res);
    }

    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        String action = req.getServletPath();
        try {
            switch (action) {
                case "/new":    showNewForm(req, res);    break;
                case "/insert": insertEmployee(req, res); break;
                case "/edit":   showEditForm(req, res);   break;
                case "/update": updateEmployee(req, res); break;
                case "/delete": deleteEmployee(req, res); break;
                default:        listEmployees(req, res);  break;
            }
        } catch (SQLException ex) {
            throw new ServletException(ex);
        }
    }

    private void listEmployees(HttpServletRequest req, HttpServletResponse res)
            throws SQLException, IOException, ServletException {
        List<Employee> list = employeeDAO.selectAllEmployees();
        req.setAttribute("listEmployee", list);
        req.getRequestDispatcher("/employeeList.jsp").forward(req, res);
    }

    private void showNewForm(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        req.getRequestDispatcher("/employeeForm.jsp").forward(req, res);
    }

    private void showEditForm(HttpServletRequest req, HttpServletResponse res)
            throws SQLException, ServletException, IOException {
        int id = Integer.parseInt(req.getParameter("id"));
        Employee emp = employeeDAO.selectEmployee(id);
        req.setAttribute("employee", emp);
        req.getRequestDispatcher("/employeeForm.jsp").forward(req, res);
    }

    private void insertEmployee(HttpServletRequest req, HttpServletResponse res)
            throws SQLException, IOException {
        Employee emp = new Employee(
            req.getParameter("name"),
            req.getParameter("email"),
            req.getParameter("position")
        );
        employeeDAO.insertEmployee(emp);
        res.sendRedirect(req.getContextPath() + "/list");
    }

    private void updateEmployee(HttpServletRequest req, HttpServletResponse res)
            throws SQLException, IOException {
        Employee emp = new Employee(
            Integer.parseInt(req.getParameter("id")),
            req.getParameter("name"),
            req.getParameter("email"),
            req.getParameter("position")
        );
        employeeDAO.updateEmployee(emp);
        res.sendRedirect(req.getContextPath() + "/list");
    }

    private void deleteEmployee(HttpServletRequest req, HttpServletResponse res)
            throws SQLException, IOException {
        int id = Integer.parseInt(req.getParameter("id"));
        employeeDAO.deleteEmployee(id);
        res.sendRedirect(req.getContextPath() + "/list");
    }
}