<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="jakarta.tags.core" prefix="c"%>
<!DOCTYPE html>
<html>
<head>
    <title>Employee Form</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>
<nav class="navbar navbar-dark" style="background-color: darkslateblue">
    <a class="navbar-brand" href="#">Employee Management</a>
    <ul class="navbar-nav">
        <li><a href="<%=request.getContextPath()%>/list" class="nav-link text-white">Employee List</a></li>
    </ul>
</nav>
<br>
<div class="container col-md-5">
    <div class="card">
        <div class="card-body">
            <c:if test="${employee != null}">
                <form action="<%=request.getContextPath()%>/update" method="post">
                <input type="hidden" name="id" value="<c:out value='${employee.id}'/>">
            </c:if>
            <c:if test="${employee == null}">
                <form action="<%=request.getContextPath()%>/insert" method="post">
            </c:if>

            <h4>
                <c:if test="${employee != null}">Edit Employee</c:if>
                <c:if test="${employee == null}">Add New Employee</c:if>
            </h4>

            <div class="form-group">
                <label>Name</label>
                <input type="text" name="name" class="form-control"
                       value="<c:out value='${employee.name}'/>" required>
            </div>
            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" class="form-control"
                       value="<c:out value='${employee.email}'/>" required>
            </div>
            <div class="form-group">
                <label>Position</label>
                <input type="text" name="position" class="form-control"
                       value="<c:out value='${employee.position}'/>" required>
            </div>
            <button type="submit" class="btn btn-primary">Save</button>
            <a href="<%=request.getContextPath()%>/list" class="btn btn-secondary">Cancel</a>
            </form>
        </div>
    </div>
</div>
</body>
</html>