<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="jakarta.tags.core" prefix="c"%>
<!DOCTYPE html>
<html>
<head>
    <title>Employee Management</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>
<nav class="navbar navbar-dark" style="background-color: darkslateblue">
    <a class="navbar-brand" href="#">Employee Management</a>
    <ul class="navbar-nav">
        <li><a href="<%=request.getContextPath()%>/list" class="nav-link text-white">Employee List</a></li>
    </ul>
</nav>
<br>
<div class="container">
    <h3 class="text-center">Employee List</h3>
    <hr>
    <div class="mb-2">
        <a href="<%=request.getContextPath()%>/new" class="btn btn-success">Add New Employee</a>
    </div>
    <table class="table table-bordered">
        <thead class="thead-dark">
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Position</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <c:forEach var="emp" items="${listEmployee}">
                <tr>
                    <td><c:out value="${emp.id}"/></td>
                    <td><c:out value="${emp.name}"/></td>
                    <td><c:out value="${emp.email}"/></td>
                    <td><c:out value="${emp.position}"/></td>
                    <td>
                        <a href="<%=request.getContextPath()%>/edit?id=<c:out value='${emp.id}'/>">Edit</a>
                        &nbsp;&nbsp;
                        <a href="<%=request.getContextPath()%>/delete?id=<c:out value='${emp.id}'/>"
                           onclick="return confirm('Delete this employee?')">Delete</a>
                    </td>
                </tr>
            </c:forEach>
        </tbody>
    </table>
</div>
</body>
</html>