<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head><title>Employee Management</title></head>
<body>
    <h2>Employee Management System</h2>
    <ul>
        <li><a href="http://localhost:8080/Employee/list">View All Employees</a></li>
        <li><a href="http://localhost:8080/Employee/new">Add New Employee</a></li>
    </ul>
</body>
</html>