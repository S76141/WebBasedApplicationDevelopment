package com.WEB;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import com.DAO.CarDAO;
import com.Model.Car;

@WebServlet(urlPatterns = {"/list", "/new", "/insert", "/edit", "/update", "/delete"})
public class CarServlet extends HttpServlet {

    private CarDAO carDAO;

    public void init() {
        carDAO = new CarDAO();
    }

    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        doGet(req, res);
    }

    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        String action = req.getServletPath();
        try {
            switch (action) {
                case "/new":    showNewForm(req, res);  break;
                case "/insert": insertCar(req, res);    break;
                case "/edit":   showEditForm(req, res); break;
                case "/update": updateCar(req, res);    break;
                case "/delete": deleteCar(req, res);    break;
                default:        listCars(req, res);     break;
            }
        } catch (SQLException ex) {
            throw new ServletException(ex);
        }
    }

    private void listCars(HttpServletRequest req, HttpServletResponse res)
            throws SQLException, IOException, ServletException {
        List<Car> cars = carDAO.selectAllCars();
        req.setAttribute("listCar", cars);
        req.getRequestDispatcher("/carList.jsp").forward(req, res);
    }

    private void showNewForm(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        req.getRequestDispatcher("/carForm.jsp").forward(req, res);
    }

    private void showEditForm(HttpServletRequest req, HttpServletResponse res)
            throws SQLException, ServletException, IOException {
        int id = Integer.parseInt(req.getParameter("id"));
        Car car = carDAO.selectCar(id);
        req.setAttribute("car", car);
        req.getRequestDispatcher("/carForm.jsp").forward(req, res);
    }

    private void insertCar(HttpServletRequest req, HttpServletResponse res)
            throws SQLException, IOException {
        Car car = new Car(
            req.getParameter("brand"),
            req.getParameter("model"),
            Integer.parseInt(req.getParameter("cylinder")),
            Double.parseDouble(req.getParameter("price"))
        );
        carDAO.insertCar(car);
        res.sendRedirect(req.getContextPath() + "/list");
    }

    private void updateCar(HttpServletRequest req, HttpServletResponse res)
            throws SQLException, IOException {
        Car car = new Car(
            Integer.parseInt(req.getParameter("id")),
            req.getParameter("brand"),
            req.getParameter("model"),
            Integer.parseInt(req.getParameter("cylinder")),
            Double.parseDouble(req.getParameter("price"))
        );
        carDAO.updateCar(car);
        res.sendRedirect(req.getContextPath() + "/list");
    }

    private void deleteCar(HttpServletRequest req, HttpServletResponse res)
            throws SQLException, IOException {
        int id = Integer.parseInt(req.getParameter("id"));
        carDAO.deleteCar(id);
        res.sendRedirect(req.getContextPath() + "/list");
    }
}