<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="jakarta.tags.core" prefix="c"%>
<!DOCTYPE html>
<html>
<head>
    <title>Car Form</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>
<nav class="navbar navbar-dark" style="background-color: steelblue">
    <a class="navbar-brand" href="#">Car Shop Management</a>
    <ul class="navbar-nav">
        <li><a href="<%=request.getContextPath()%>/list" class="nav-link text-white">Car List</a></li>
    </ul>
</nav>
<br>
<div class="container col-md-5">
    <div class="card">
        <div class="card-body">
            <c:if test="${car != null}">
                <form action="<%=request.getContextPath()%>/update" method="post">
                <input type="hidden" name="id" value="<c:out value='${car.carId}'/>">
            </c:if>
            <c:if test="${car == null}">
                <form action="<%=request.getContextPath()%>/insert" method="post">
            </c:if>

            <h4>
                <c:if test="${car != null}">Edit Car</c:if>
                <c:if test="${car == null}">Add New Car</c:if>
            </h4>

            <div class="form-group">
                <label>Brand</label>
                <input type="text" name="brand" class="form-control"
                       value="<c:out value='${car.brand}'/>" required>
            </div>
            <div class="form-group">
                <label>Model</label>
                <input type="text" name="model" class="form-control"
                       value="<c:out value='${car.model}'/>" required>
            </div>
            <div class="form-group">
                <label>Cylinders</label>
                <input type="number" name="cylinder" class="form-control"
                       value="<c:out value='${car.cylinder}'/>" required>
            </div>
            <div class="form-group">
                <label>Price (RM)</label>
                <input type="number" step="0.01" name="price" class="form-control"
                       value="<c:out value='${car.price}'/>" required>
            </div>
            <button type="submit" class="btn btn-primary">Save</button>
            <a href="<%=request.getContextPath()%>/list" class="btn btn-secondary">Cancel</a>
            </form>
        </div>
    </div>
</div>
</body>
</html>