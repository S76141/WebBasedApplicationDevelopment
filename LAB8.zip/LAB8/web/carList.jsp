<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="jakarta.tags.core" prefix="c"%>
<!DOCTYPE html>
<html>
<head>
    <title>Car Shop</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>
<nav class="navbar navbar-dark" style="background-color: steelblue">
    <a class="navbar-brand" href="#">Car Shop Management</a>
    <ul class="navbar-nav">
        <li><a href="<%=request.getContextPath()%>/list" class="nav-link text-white">Car List</a></li>
    </ul>
</nav>
<br>
<div class="container">
    <h3 class="text-center">Car Price List</h3>
    <hr>
    <div class="mb-2">
        <a href="<%=request.getContextPath()%>/new" class="btn btn-success">Add New Car</a>
    </div>
    <table class="table table-bordered">
        <thead class="thead-dark">
            <tr>
                <th>ID</th>
                <th>Brand</th>
                <th>Model</th>
                <th>Cylinders</th>
                <th>Price (RM)</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <c:forEach var="car" items="${listCar}">
                <tr>
                    <td><c:out value="${car.carId}"/></td>
                    <td><c:out value="${car.brand}"/></td>
                    <td><c:out value="${car.model}"/></td>
                    <td><c:out value="${car.cylinder}"/></td>
                    <td><c:out value="${car.price}"/></td>
                    <td>
                        <a href="<%=request.getContextPath()%>/edit?id=<c:out value='${car.carId}'/>">Edit</a>
                        &nbsp;&nbsp;
                        <a href="<%=request.getContextPath()%>/delete?id=<c:out value='${car.carId}'/>"
                           onclick="return confirm('Delete this car?')">Delete</a>
                    </td>
                </tr>
            </c:forEach>
        </tbody>
    </table>
</div>
</body>
</html>