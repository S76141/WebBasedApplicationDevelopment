<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head><title>Car Shop MVC</title></head>
<body>
    <h2>Car Shop MVC Application</h2>
    <ul>
        <li><a href="http://localhost:8080/LAB8/list">View All Cars</a></li>
        <li><a href="http://localhost:8080/LAB8/new">Add New Car</a></li>
    </ul>
</body>
</html>