package Lab6.com;

import java.sql.*;

public class Database {
    private static Connection myConnection = null;
    private static String myURL = "jdbc:mysql://localhost:3306/csf3107";
    private int result = 0;

    public static Connection getConnection() throws ClassNotFoundException {
        if (myConnection != null) {
            return myConnection;
        } else {
            try {
                Class.forName("com.mysql.jdbc.Driver");
                myConnection = DriverManager.getConnection(myURL, "root", "admin");
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return myConnection;
        }
    }

    public void closeConnection() throws ClassNotFoundException {
        try {
            myConnection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}