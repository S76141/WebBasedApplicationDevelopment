package Lab6.com;

import java.util.regex.*;

public class Student {
    private String stuno;
    private String valid;
    private String invalid = "invalid";
    private String name;
    private String program;

    // Stuno getter with regex validation
    public String getStuno() {
        Pattern pt = Pattern.compile("[A-Z][0-9]*");
        Matcher mt = pt.matcher(stuno);
        boolean bl = mt.matches();
        if (bl == true) {
            valid = stuno;
        } else {
            valid = invalid;
        }
        return valid;
    }

    public void setStuno(String stuno) { this.stuno = stuno; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getProgram() { return program; }
    public void setProgram(String program) { this.program = program; }
}