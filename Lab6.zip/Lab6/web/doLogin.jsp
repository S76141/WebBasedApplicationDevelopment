<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.sql.*"%>
<!DOCTYPE html>
<html>
<head><title>Validating...</title></head>
<body>
<%
    String username = request.getParameter("username");
    String password = request.getParameter("password");

    Class.forName("com.mysql.jdbc.Driver");
    Connection con = DriverManager.getConnection("jdbc:mysql://localhost/csf3107", "root", "admin");

    String sql = "SELECT * FROM userprofile WHERE username=? AND password=?";
    PreparedStatement ps = con.prepareStatement(sql);
    ps.setString(1, username);
    ps.setString(2, password);

    ResultSet rs = ps.executeQuery();

    if (rs.next()) {
        // Valid: store in session and redirect to main.jsp
        session.setAttribute("username",  rs.getString("username"));
        session.setAttribute("firstname", rs.getString("firstname"));
        session.setAttribute("lastname",  rs.getString("lastname"));
        response.sendRedirect("main.jsp");
    } else {
        // Invalid: send back to login with error flag
        response.sendRedirect("login.jsp?error=1");
    }

    con.close();
%>
</body>
</html>