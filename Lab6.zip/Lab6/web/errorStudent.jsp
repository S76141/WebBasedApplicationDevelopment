<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page isErrorPage="true"%>
<!DOCTYPE html>
<html>
<head><title>Error</title></head>
<body>
  <h1>Error when inserting record...!</h1>
  <p><jsp:expression>exception.getMessage()</jsp:expression></p>
</body>
</html>