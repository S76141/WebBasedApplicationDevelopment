<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head><title>Lab 6 - Task 2</title></head>
<body>
<h1>Lab 6 - Task 2 - Perform creating and retrieving records via JSP page</h1>

<form action="processAuthor.jsp" method="post">
<fieldset>
  <legend>Author Registration</legend>
  <table>
    <tr><td>Author No</td><td><input type="text" name="authno" placeholder="E.g.: UKXXXXX"/></td></tr>
    <tr><td>Name</td><td><input type="text" name="name" placeholder="Enter your name"/></td></tr>
    <tr><td>Address</td><td><input type="text" name="address" placeholder="Enter your address"/></td></tr>
    <tr><td>City</td><td><input type="text" name="city" placeholder="Enter your city"/></td></tr>
    <tr><td>State</td><td><input type="text" name="state" placeholder="Enter your state"/></td></tr>
    <tr><td>Zip</td><td><input type="text" name="zip" placeholder="Enter your zip"/></td></tr>
  </table>
  <br>
  <input type="submit" value="Submit"/>
  <input type="reset" value="Cancel"/>
</fieldset>
</form>

<footer><p>©2026-Ding Wei Qi</p></footer>
</body>
</html>