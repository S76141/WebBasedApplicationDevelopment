<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head><title>Lab 6 - Task 3</title></head>
<body>
<h1>Lab 6 - Task 3 - Student Registration</h1>

<form action="processStudent.jsp" method="post">
<fieldset>
  <legend>Student Registration</legend>
  <table>
    <tr>
      <td>Student No</td>
      <td><input type="text" name="stuno" placeholder="E.g.: UKXXXXX"/></td>
    </tr>
    <tr>
      <td>Name</td>
      <td><input type="text" name="name" placeholder="Enter your name"/></td>
    </tr>
    <tr>
      <td>Program</td>
      <td>
        <select name="program">
          <option value="BSc. Soft. Eng.">BSc. Soft. Eng.</option>
          <option value="BSc. with IM">BSc. with IM</option>
          <option value="BSc. in Networking">BSc. in Networking</option>
          <option value="BSc. in Robotics">BSc. in Robotics</option>
        </select>
      </td>
    </tr>
  </table>
  <br>
  <input type="submit" value="Submit"/>
  <input type="reset" value="Cancel"/>
</fieldset>
</form>

<p>©2026- Ding Wei Qi</p>
</body>
</html>