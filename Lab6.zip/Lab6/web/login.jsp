<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head><title>Login</title></head>
<body>
<h1>Login</h1>

<%
    // Show error message if redirected back from doLogin.jsp
    String error = request.getParameter("error");
    if (error != null) {
        out.println("<p style='color:red;'>Invalid username or password..!</p>");
    }
%>

<form action="doLogin.jsp" method="post">
<table>
  <tr><td>Username</td><td><input type="text" name="username"/></td></tr>
  <tr><td>Password</td><td><input type="password" name="password"/></td></tr>
</table>
<br>
<input type="submit" value="Login"/>
</form>
</body>
</html>