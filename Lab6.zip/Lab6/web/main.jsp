<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head><title>Welcome</title></head>
<body>
<%
    String username  = (String) session.getAttribute("username");
    String firstname = (String) session.getAttribute("firstname");
    String lastname  = (String) session.getAttribute("lastname");

    if (username == null) {
        // Not logged in, redirect to login
        response.sendRedirect("login.jsp");
    } else {
%>
    <h1>Welcome, <%= firstname %> <%= lastname %>!</h1>
    <p>Username: <%= username %></p>
    <a href="login.jsp">Logout</a>
<%
    }
%>
</body>
</html>