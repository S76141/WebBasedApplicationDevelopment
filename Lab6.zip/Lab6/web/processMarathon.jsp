<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.sql.*"%>
<%@page import="Lab6.com.Database"%>
<%@page import="Lab6.com.Marathon"%>
<%@page import="Lab6.com.MarathonDAO"%>
<!DOCTYPE html>
<html>
<head><title>Process Marathon</title></head>
<body>

<!-- Create Marathon bean object -->
<jsp:useBean id="myMarathon" class="Lab6.com.Marathon" scope="request"/>
<jsp:setProperty name="myMarathon" property="*"/>

<%
    int result;

    // Step 1: Create Database and DAO objects
    Database myDB = new Database();
    MarathonDAO object1 = new MarathonDAO();

    // Step 2: Add the record
    result = object1.addDetails(myMarathon);

    // Step 3: Check result
    if (result > 0) {
        out.print("<p>" + "Record with IC No " + myMarathon.getIcno() + " successfully created..!" + "</p>");
        out.print("<p>" + "Details of record are; " + "</p>");
        out.print("<p>Ic No    : " + myMarathon.getIcno() + "</p>");
        out.print("<p>Name     : " + myMarathon.getName() + "</p>");
        out.print("<p>Category : " + myMarathon.getCategory() + "</p>");
    }

    // Step 4: Close connection
    myDB.closeConnection();
%>

<p>©2026-Ding Wei Qi</p>
</body>
</html>