<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page language="java"%>
<%@page import="java.sql.*"%>
<%@page errorPage="errorStudent.jsp"%>
<!DOCTYPE html>
<html>
<head><title>Process Student</title></head>
<body>

<jsp:useBean id="myStudent" class="Lab6.com.Student" scope="request"/>
<jsp:setProperty name="myStudent" property="*"/>

<%
    int result;

    Class.forName("com.mysql.jdbc.Driver");
    String myURL = "jdbc:mysql://localhost/csf3107";
    Connection myConnection = DriverManager.getConnection(myURL, "root", "admin");

    String sInsertQry = "INSERT INTO Student(stuno, stuname, stuprogram) VALUES(?, ?, ?)";
    PreparedStatement myPS = myConnection.prepareStatement(sInsertQry);

    myPS.setString(1, myStudent.getStuno());
    myPS.setString(2, myStudent.getName());
    myPS.setString(3, myStudent.getProgram());

    result = myPS.executeUpdate();

    if (result > 0) {
        out.print("<p>" + "Record with student no " + myStudent.getStuno() + " successfully created..!" + "</p>");
        out.print("<p>" + "Details of record are; " + "</p>");
        out.print("<p>Student ID : " + myStudent.getStuno() + "</p>");
        out.print("<p>Name : " + myStudent.getName() + "</p>");
        out.print("<p>Program : " + myStudent.getProgram() + "</p>");
    }

    myConnection.close();
%>

</body>
</html>