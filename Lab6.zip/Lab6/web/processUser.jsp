<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.sql.*"%>
<!DOCTYPE html>
<html>
<head><title>Process User</title></head>
<body>
<%
    String username  = request.getParameter("username");
    String password  = request.getParameter("password");
    String firstname = request.getParameter("firstname");
    String lastname  = request.getParameter("lastname");

    Class.forName("com.mysql.jdbc.Driver");
    Connection con = DriverManager.getConnection("jdbc:mysql://localhost/csf3107", "root", "admin");

    String sql = "INSERT INTO userprofile(username, password, firstname, lastname) VALUES(?,?,?,?)";
    PreparedStatement ps = con.prepareStatement(sql);
    ps.setString(1, username);
    ps.setString(2, password);
    ps.setString(3, firstname);
    ps.setString(4, lastname);

    int result = ps.executeUpdate();
    if (result > 0) {
        out.println("<p>User " + username + " registered successfully!</p>");
        out.println("<a href='login.jsp'>Go to Login</a>");
    }
    con.close();
%>
</body>
</html>