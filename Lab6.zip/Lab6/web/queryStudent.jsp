<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.sql.*"%>
<!DOCTYPE html>
<html>
<head>
<title>Lab 6 - Task 4</title>
<style>
    table { border-collapse: collapse; }
    td, th {
        border: 1px solid #999;
        padding: 0.5rem;
        text-align: left;
    }
    th { background: gold; }
</style>
</head>
<body>

<h1>Lab 6 - Task 4 : Retrieving record via JSP page</h1>

<%
    // Step 1: Load driver
    Class.forName("com.mysql.jdbc.Driver");

    // Step 2: Connect
    String myURL = "jdbc:mysql://localhost/csf3107";
    Connection myConnection = DriverManager.getConnection(myURL, "root", "admin");

    // Step 3: Create statement
    Statement myStatement = myConnection.createStatement();

    // Step 4: Execute query
    String myQuery = "SELECT * FROM student";
    ResultSet myResultSet = myStatement.executeQuery(myQuery);
%>

<table>
    <thead>
        <tr>
            <th>ISBNNo</th>
            <th>Author</th>
            <th>Title</th>
        </tr>
    </thead>
    <tbody>
    <%
        while (myResultSet.next()) {
            out.print("<tr>");
            out.print("<td width=\"20%\">" + myResultSet.getString(1) + "</td>");
            out.print("<td width=\"40%\">" + myResultSet.getString(2) + "</td>");
            out.print("<td width=\"40%\">" + myResultSet.getString(3) + "</td>");
            out.print("</tr>");
        }

        // Step 5: Close
        myConnection.close();
    %>
    </tbody>
</table>

</body>
</html>