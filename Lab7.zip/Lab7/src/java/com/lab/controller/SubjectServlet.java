package com.lab.controller;

import com.lab.bean.StudentBean;
import com.lab.bean.SubjectBean;
import com.lab.dao.SubjectDAO;
import java.io.IOException;
import java.util.List;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

public class SubjectServlet extends HttpServlet {

    private SubjectDAO subjectDAO = new SubjectDAO();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loggedUser") == null) {
            response.sendRedirect(request.getContextPath() + "/login.html");
            return;
        }
        StudentBean loggedUser = (StudentBean) session.getAttribute("loggedUser");

        String action = request.getParameter("action");

        if ("add".equals(action)) {
            SubjectBean s = new SubjectBean();
            s.setMatricNo(loggedUser.getMatricNo());
            s.setSubjectCode(request.getParameter("subjectCode"));
            s.setSubjectName(request.getParameter("subjectName"));
            subjectDAO.addSubject(s);
            // FIX: use sendRedirect with context path
            response.sendRedirect(request.getContextPath() + "/SubjectServlet?action=view");

        } else if ("update".equals(action)) {
            SubjectBean s = new SubjectBean();
            s.setId(Integer.parseInt(request.getParameter("id")));
            s.setSubjectCode(request.getParameter("subjectCode"));
            s.setSubjectName(request.getParameter("subjectName"));
            subjectDAO.updateSubject(s);
            response.sendRedirect(request.getContextPath() + "/SubjectServlet?action=view");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loggedUser") == null) {
            response.sendRedirect(request.getContextPath() + "/login.html");
            return;
        }
        StudentBean loggedUser = (StudentBean) session.getAttribute("loggedUser");

        String action = request.getParameter("action");

        if ("view".equals(action)) {
            List<SubjectBean> subjects =
                subjectDAO.getSubjectsByMatric(loggedUser.getMatricNo());
            request.setAttribute("subjects", subjects);
            // FIX: forward path relative to web root
            request.getRequestDispatcher("/subject/viewSubjects.jsp")
                   .forward(request, response);

        } else if ("showAdd".equals(action)) {
            // FIX: forward to register form via servlet, not direct link
            request.getRequestDispatcher("/subject/registerSubject.jsp")
                   .forward(request, response);

        } else if ("edit".equals(action)) {
            int id = Integer.parseInt(request.getParameter("id"));
            SubjectBean s = subjectDAO.getSubjectById(id);
            request.setAttribute("subject", s);
            request.getRequestDispatcher("/subject/updateSubject.jsp")
                   .forward(request, response);

        } else if ("delete".equals(action)) {
            int id = Integer.parseInt(request.getParameter("id"));
            subjectDAO.deleteSubject(id);
            response.sendRedirect(request.getContextPath() + "/SubjectServlet?action=view");
        }
    }
}