<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="com.lab.bean.StudentBean"%>
<!DOCTYPE html>
<html>
<head>
    <title>Student Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
          rel="stylesheet">
    <style>
        .profile-img {
            width: 160px;
            height: 160px;
            object-fit: cover;
            border: 5px solid #198754;
        }
    </style>
</head>
<body class="bg-light">

<%
    StudentBean user = (StudentBean) session.getAttribute("loggedUser");
    if (user == null) {
        response.sendRedirect("login.html");
        return;
    }
%>

<div class="container d-flex justify-content-center align-items-center"
     style="min-height: 100vh;">
    <div class="card shadow-lg border-0 rounded-4 p-5 text-center"
         style="max-width: 600px; width: 100%;">
        <div class="card-body">

            <img src="data:image/jpeg;base64,<%= user.getBase64Image() %>"
                 alt="Profile"
                 class="profile-img rounded-circle shadow-sm mb-4"/>

            <h2 class="fw-bold text-dark mb-2">
                Welcome, <%= user.getFullname() %>!
            </h2>
            <p class="text-muted fs-5 mb-4">
                Matric No: <strong><%= user.getMatricNo() %></strong>
            </p>

            <div class="d-flex justify-content-center gap-3 flex-wrap">

                <!-- FIX: go through SubjectServlet, not direct JSP -->
                <a href="SubjectServlet?action=view"
                   class="btn btn-success px-4 py-2 fw-semibold">
                    My Subjects
                </a>

                <a href="UserServlet?action=logout"
                   class="btn btn-dark px-4 py-2 fw-semibold">
                    Logout
                </a>

                <a href="UserServlet?action=delete"
                   onclick="return confirm('Delete your account permanently?');"
                   class="btn btn-danger px-4 py-2 fw-semibold">
                    Delete Account
                </a>
            </div>

        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js">
</script>
</body>
</html>