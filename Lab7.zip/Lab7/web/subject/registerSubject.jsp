<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="com.lab.bean.StudentBean"%>
<!DOCTYPE html>
<html>
<head><title>Register Subject</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
      rel="stylesheet">
</head>
<body class="bg-light p-4">
<%
    StudentBean user = (StudentBean) session.getAttribute("loggedUser");
    if (user == null) {
        response.sendRedirect(request.getContextPath() + "/login.html");
        return;
    }
%>

<div class="card p-4 mx-auto" style="max-width:500px;">
    <h2>Register New Subject</h2>
    <p>Student: <strong><%= user.getFullname() %></strong></p>

    <!-- FIX: action uses getContextPath() -->
    <form action="<%= request.getContextPath() %>/SubjectServlet" method="POST">
        <input type="hidden" name="action" value="add">

        <div class="mb-3">
            <label>Subject Code</label>
            <input type="text" name="subjectCode" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Subject Name</label>
            <input type="text" name="subjectName" class="form-control" required>
        </div>

        <input type="submit" value="Register Subject" class="btn btn-primary">
        <a href="<%= request.getContextPath() %>/SubjectServlet?action=view"
           class="btn btn-secondary">Back to My Subjects</a>
    </form>
</div>
</body>
</html>