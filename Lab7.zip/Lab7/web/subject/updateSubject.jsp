<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="com.lab.bean.StudentBean"%>
<%@page import="com.lab.bean.SubjectBean"%>
<!DOCTYPE html>
<html>
<head><title>Update Subject</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
      rel="stylesheet">
</head>
<body class="bg-light p-4">
<%
    StudentBean user = (StudentBean) session.getAttribute("loggedUser");
    if (user == null) {
        response.sendRedirect(request.getContextPath() + "/login.html");
        return;
    }
    SubjectBean s = (SubjectBean) request.getAttribute("subject");
    if (s == null) {
        response.sendRedirect(request.getContextPath() + "/SubjectServlet?action=view");
        return;
    }
%>

<div class="card p-4 mx-auto" style="max-width:500px;">
    <h2>Update Subject</h2>

    <form action="<%= request.getContextPath() %>/SubjectServlet" method="POST">
        <input type="hidden" name="action" value="update">
        <input type="hidden" name="id" value="<%= s.getId() %>">

        <div class="mb-3">
            <label>Subject Code</label>
            <input type="text" name="subjectCode"
                   value="<%= s.getSubjectCode() %>"
                   class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Subject Name</label>
            <input type="text" name="subjectName"
                   value="<%= s.getSubjectName() %>"
                   class="form-control" required>
        </div>

        <input type="submit" value="Update" class="btn btn-warning">
        <a href="<%= request.getContextPath() %>/SubjectServlet?action=view"
           class="btn btn-secondary">Cancel</a>
    </form>
</div>
</body>
</html>