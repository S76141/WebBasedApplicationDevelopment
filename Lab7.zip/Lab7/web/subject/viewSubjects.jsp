<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="com.lab.bean.StudentBean"%>
<%@page import="com.lab.bean.SubjectBean"%>
<%@page import="java.util.List"%>
<!DOCTYPE html>
<html>
<head>
    <title>My Subjects</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
          rel="stylesheet">
</head>
<body class="bg-light p-4">
<%
    StudentBean user = (StudentBean) session.getAttribute("loggedUser");
    if (user == null) {
        response.sendRedirect(request.getContextPath() + "/login.html");
        return;
    }
%>

<div class="container">
    <h2>My Registered Subjects</h2>
    <p>Student: <strong><%= user.getFullname() %></strong>
       | Matric: <strong><%= user.getMatricNo() %></strong></p>

    <a href="<%= request.getContextPath() %>/SubjectServlet?action=showAdd"
       class="btn btn-primary mb-3">+ Register New Subject</a>
    <a href="<%= request.getContextPath() %>/dashboard.jsp"
       class="btn btn-secondary mb-3">Back to Dashboard</a>

    <%
        List<SubjectBean> subjects =
            (List<SubjectBean>) request.getAttribute("subjects");
        if (subjects == null || subjects.isEmpty()) {
    %>
        <p class="text-muted">No subjects registered yet.</p>
    <%
        } else {
    %>
    <table class="table table-bordered table-striped">
        <thead class="table-success">
            <tr>
                <th>No</th>
                <th>Subject Code</th>
                <th>Subject Name</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <%
            int count = 1;
            for (SubjectBean s : subjects) {
        %>
            <tr>
                <td><%= count++ %></td>
                <td><%= s.getSubjectCode() %></td>
                <td><%= s.getSubjectName() %></td>
                <td>
                    <a href="<%= request.getContextPath() %>/SubjectServlet?action=edit&id=<%= s.getId() %>"
                       class="btn btn-warning btn-sm">Edit</a>
                    <a href="<%= request.getContextPath() %>/SubjectServlet?action=delete&id=<%= s.getId() %>"
                       onclick="return confirm('Delete this subject?');"
                       class="btn btn-danger btn-sm">Delete</a>
                </td>
            </tr>
        <%
            }
        %>
        </tbody>
    </table>
    <%
        }
    %>
</div>
</body>
</html>