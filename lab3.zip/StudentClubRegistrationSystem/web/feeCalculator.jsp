<%-- 
    Document   : feeCalculator
    Created on : 2026年4月20日, 21:50:23
    Author     : DING WEI QI
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <%@include file="header.jsp" %>
        <h3>Fee Calculator</h3>
        <form method-"post>
            Number of Activities:
            <input type="number" name="activities" required> 
            <input type="submit" value="Calculate">
        </form>
        
        <%
            if(request.getParameter("activities")!= null){
                int activities= Integer.parseInt(request.getParameter("activities"));
                double total= activities*10;
                java.text.DecimalFormat df= new java.text.DecimalFormat("0.00");
        %>
        <p>Total Fee: RM <%= df.format(total) %></p>
        
        <%
            }
        %>
        <%@include file="footer.jsp" %>
    </body>
</html>
