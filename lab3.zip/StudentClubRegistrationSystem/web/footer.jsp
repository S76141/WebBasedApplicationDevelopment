<%-- 
    Document   : footer
    Created on : 2026年5月2日, 21:56:00
    Author     : DING WEI QI
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <footer>
            <p>&copy; 2026 UMT Student Club System</p>
        </footer>
    </body>
</html>
