<%-- 
    Document   : header
    Created on : 2026年4月20日, 21:16:03
    Author     : DING WEI QI
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <title>Student Club System</title>
        <style>
            nav{
                width:30%;
                border:10px;
                margin:10px;
                padding:10px;
                background-color:lavender;
            }
        </style>
    </head>
    <body>
        <h1>UMT Student Club Recruiment</h1>
        <nav>
            <a href="registerClub.jsp">Registration Page</a><br>
            <a href="feeCalculator.jsp">Fee Calculator</a><br>
            <a href="memberDirectory.jsp">Club Member Directory</a>
        </nav>
        

    </body>
</html>
