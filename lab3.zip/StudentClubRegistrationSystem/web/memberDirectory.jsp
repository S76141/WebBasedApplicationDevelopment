<%-- 
    Document   : memberDirectory
    Created on : 2026年5月2日, 22:08:00
    Author     : DING WEI QI
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.util.ArrayList" %>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <%@include file="header.jsp" %>
        <%
            ArrayList<String> memberList= new ArrayList<String>();
            memberList.add(0,"Ali");
            memberList.add(1,"Abu");
            memberList.add(2,"Akau");
            memberList.add(3,"Amin");
            memberList.add(4,"Afiq");
            memberList.add(5,"Abin");
            
            out.println("<p>The total member is "+memberList.size()+"</p>");
            
            for(int i=0; i<memberList.size();i++){
                out.println("<p>"+(i+1)+". "+memberList.get(i)+"</p>");
            }
        %>
        <%@include file="footer.jsp" %>
    </body>
</html>
