<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <%@ include file="header.jsp" %>
        <h3>Registration Details</h3>
        <%
            String name=request.getParameter("studentName");
            String matric= request.getParameter("matricNo");
            String club= request.getParameter("club");
        %>
        <p>Name: <%=name %></p>
        <p>Matric Number: <%= matric %></p>
        <p>Selected Club: <%= club %></p> 
        
        <%@ include file="footer.jsp" %>
    </body>
</html>
