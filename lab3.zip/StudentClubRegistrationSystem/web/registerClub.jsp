
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <%@ include file="header.jsp" %>
        <h3>Club Registration</h3>
        <form action="processRegistration.jsp" method="post">
            Name:<input type="text" name="studentName" required><br><br>
            Matric Number:<input type="text" name="matricNo" required><br><br>
            Select Club:
            <select name="club">
                <option value="Programming Club">Programming Club</option>
                <option value="AI Club">AI Club</option>
                <option value="Cyber Security Club">Cyber Security Club</option>
            </select><br><br>
            <input type="submit" value="Register">
        </form>
        <%@ include file= "footer.jsp" %>
    </body>
</html>
