<%-- 
    Document   : bmiCalculator
    Created on : May 12, 2026, 11:22:41 AM
    Author     : Huawei
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <%@include file="header.jsp" %>
        <h1>BMI Calculator</h1>
        <form action="processBmi.jsp" method="post">
            <fieldset>
                <div class="form-group">
                    <label for="weight">Weight(kg):</label>
                    <input type="number" id="weight" name="weight" placeholder="80" required>
                </div>
                <div class="form-group">
                    <label for="height">Height(cm):</label>
                    <input type="number" id="height" name="height" placeholder="180" required>
                </div>
                <div class="btn">
                    <input type="submit" value="submit" name="btnSubmit">
                    <input type="reset" value="cancel" name="btnCancel">
                </div>
            </fieldset>
        </form>
        <%@include file="footer.jsp" %>
    </body>
</html>
