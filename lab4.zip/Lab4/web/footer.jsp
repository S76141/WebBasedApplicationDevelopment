<%-- 
    Document   : footer
    Created on : May 12, 2026, 11:14:15 AM
    Author     : Huawei
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <footer>
            <p>&copy;Ding Wei Qi UMT</p>
        </footer>
    </body>
</html>
