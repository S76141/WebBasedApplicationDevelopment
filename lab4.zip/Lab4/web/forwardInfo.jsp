
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <h1>Using jsp:forward to display user information</h1>
        <div class="card">
        <%
            String name = request.getParameter("uname");
            String email = request.getParameter("email");
            String nationality = request.getParameter("nationality");
            String background = request.getParameter("background");
        %>
        
        <p>Name: <%= name %></p>
        <p>Email: <%= email %></p>
        <p>Nationality: <%= nationality %></p>
        <p>Background: <%= background %></p>
        </div>
    </body>
</html>
