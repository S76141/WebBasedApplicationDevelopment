<%-- 
    Document   : header
    Created on : May 12, 2026, 11:13:48 AM
    Author     : Huawei
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
        <style>
            ul {
                list-style-type: none;
                margin: 0;
                padding: 0;
            }
        </style>
    </head>
    <body>
        <nav>
            <ul>
                <li><a href=" bmiCalculator.jsp">BMI Calculator Page</a></li>
                <li><a href="processBmi.jsp">Result Page</a></li>
                <li><a href="healthInfo.jsp">Health Information Page</a></li>
            </ul>
        </nav>
    </body>
</html>
