<%-- 
    Document   : healthInfo
    Created on : May 12, 2026, 12:50:25 PM
    Author     : Huawei
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ page import="java.util.ArrayList" %>
<%@ page import="java.util.HashMap" %>
<%@ page import="java.util.Map" %>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <%@ include file="header.jsp" %>

<div class="content">
    <h2>ℹ️ Health Information - BMI Categories</h2>
    <p style="color: #666; margin-bottom: 20px;">Understanding your Body Mass Index (BMI) category</p>
    
    <%
        // Store BMI categories using an ArrayList with HashMaps
        ArrayList<Map<String, String>> bmiCategories = new ArrayList<>();
        
        // Add category 1: Underweight
        Map<String, String> underweight = new HashMap<>();
        underweight.put("category", "Underweight");
        underweight.put("bmiRange", "&lt; 18.5");
        underweight.put("healthRisk", "Risk of malnutrition, osteoporosis, and anemia");
        underweight.put("recommendation", "Consult a nutritionist for a balanced diet plan");
        bmiCategories.add(underweight);
        
        // Add category 2: Normal
        Map<String, String> normal = new HashMap<>();
        normal.put("category", "Normal");
        normal.put("bmiRange", "18.5 - 25");
        normal.put("healthRisk", "Low risk of weight-related diseases");
        normal.put("recommendation", "Maintain healthy eating and regular exercise");
        bmiCategories.add(normal);
        
        // Add category 3: Overweight
        Map<String, String> overweight = new HashMap<>();
        overweight.put("category", "Overweight");
        overweight.put("bmiRange", "&gt; 25");
        overweight.put("healthRisk", "Risk of heart disease, diabetes, and high blood pressure");
        overweight.put("recommendation", "Start an exercise program and consult a doctor");
        bmiCategories.add(overweight);
    %>
    
    <!-- Display the categories dynamically in a table -->
    <table style="width: 100%; border-collapse: collapse; margin-top: 20px;">
        <thead>
            <tr style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white;">
                <th style="padding: 12px; border: 1px solid #ddd; text-align: left;">BMI Category</th>
                <th style="padding: 12px; border: 1px solid #ddd; text-align: left;">BMI Range</th>
                <th style="padding: 12px; border: 1px solid #ddd; text-align: left;">Health Risk</th>
                <th style="padding: 12px; border: 1px solid #ddd; text-align: left;">Recommendation</th>
            </tr>
        </thead>
        <tbody>
            <%
                for (Map<String, String> category : bmiCategories) {
                    String categoryClass = "";
                    if (category.get("category").equals("Underweight")) {
                        categoryClass = "#fff3e0";
                    } else if (category.get("category").equals("Normal")) {
                        categoryClass = "#e8f5e9";
                    } else {
                        categoryClass = "#ffebee";
                    }
            %>
            <tr style="background-color: <%= categoryClass %>;">
                <td style="padding: 12px; border: 1px solid #ddd; font-weight: bold;"><%= category.get("category") %></td>
                <td style="padding: 12px; border: 1px solid #ddd;"><%= category.get("bmiRange") %></td>
                <td style="padding: 12px; border: 1px solid #ddd;"><%= category.get("healthRisk") %></td>
                <td style="padding: 12px; border: 1px solid #ddd;"><%= category.get("recommendation") %></td>
            </tr>
            <%
                }
            %>
        </tbody>
    </table>
    
    <div style="margin-top: 30px; padding: 20px; background: #e3f2fd; border-radius: 10px; border-left: 4px solid #2196f3;">
        <h3 style="color: #1976d2;">💡 Important Note:</h3>
        <p>BMI is a screening tool and does not directly measure body fat. 
            It may not be accurate for athletes, pregnant women, or elderly individuals. 
            Always consult with healthcare professionals for personalized advice.</p>
    </div>
    
    <div style="margin-top: 20px; text-align: center;">
        <a href="bmiCalculator.jsp" style="background: #667eea; color: white; 
           padding: 10px 20px; text-decoration: none; border-radius: 5px; display: inline-block;">
            Calculate Your BMI Now
        </a>
    </div>
</div>x

<%@ include file="footer.jsp" %>
    </body>
</html>
