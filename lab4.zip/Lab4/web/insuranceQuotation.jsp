<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <h1>Insurance Calculation</h1>
        <div class="card">
            <form action="processInsuranceQuo.jsp" method="post">
                <fieldset>
                <legend>Insurance Calculation</legend>
                <div class="form-group">
                    <label for="icno">IC No*</label>
                    <input type="text" id="icno" name="icno" placeholder="E.g. 821210-05-3478" required>
                </div>
                <div class="form-group">
                    <label for="name">Name*</label>
                    <input type="text" id="name" name="name" placeholder="Enter name" required>
                </div>
                <div class="form-group">
                    <label for="marketprice">Market Price*</label>
                    <input type="number" id="marketprice" name="marketprice" placeholder="Price">
                </div>
                <label for="coveragetype">Coverage Type</label>
                <select name="coveragetype" id="coveragetype">
                    <option value="Third Party">Third Party</option>
                    <option value="Comprehensive">Comprehensive</option>
                </select>
                <label for="ncd">No Claim Discount(NCD)</label>
                <select name="ncd" id="ncd">
                    <option value="0.1">10%</option>
                    <option value="0.2">20%</option>
                    <option value="0.55">55%</option>
                </select>                
                
                <div class="btn">
                    <input type="submit" value="submit" name="btnSubmit">
                    <input type="reset" value="cancel" name="btnCancel">
                </div>
                </fieldset>
            </form>
        </div>
    </body>
</html>
