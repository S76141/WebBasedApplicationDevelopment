<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Processing BMI</title>
    </head>
    <body>
        <%@include file="header.jsp" %>
        <%
            String weight = request.getParameter("weight");
            String height = request.getParameter("height");
            
            double uWeight = 0;
            double uHeight = 0;
            String errorMessage = "";
            String category = "";
            String bmiValue = "";
            
            if(weight != null && height != null && !weight.trim().isEmpty() && !height.trim().isEmpty()){
                try{               
                    uWeight = Double.parseDouble(weight);  
                    uHeight = Double.parseDouble(height);  
                } catch(Exception e){
                    uWeight = 0;
                    uHeight = 0;
                    errorMessage = "Please enter valid numbers!";
                }
            } else {
                errorMessage = "Please fill in all fields!";
            }
            
            // Check for errors first
            if(!errorMessage.isEmpty()){
                // If there's an error, show it and don't forward
                out.println("<div style='color: red; text-align: center; padding: 20px;'>");
                out.println("<h3>Error: " + errorMessage + "</h3>");
                out.println("<a href='bmiCalculator.jsp' style='background: #667eea; color: white; "
                        + "padding: 10px 20px; text-decoration: none; border-radius: 5px;'>");
                out.println("Go Back to Calculator");
                out.println("</a>");
                out.println("</div>");
            } else if(uHeight == 0){
                out.println("<div style='color: red; text-align: center; padding: 20px;'>");
                out.println("<h3>Error: Height cannot be zero!</h3>");
                out.println("<a href='bmiCalculator.jsp' style='background: #667eea; color: white; "
                        + "padding: 10px 20px; text-decoration: none; border-radius: 5px;'>");
                out.println("Go Back to Calculator");
                out.println("</a>");
                out.println("</div>");
            } else {

                double bmi = uWeight / ((uHeight * uHeight)/10000);
                
                
                bmiValue = String.format("%.2f", bmi);
                
                if (bmi < 18.5) {
                    category = "Underweight";
                } else if (bmi <= 25) {
                    category = "Normal";
                } else {
                    category = "Overweight";
                }
                
                // Forward to result page with parameters
                %>
                <jsp:forward page="resultBmi.jsp">
                    <jsp:param name="bmi" value="<%= bmiValue %>" />
                    <jsp:param name="category" value="<%= category %>" />
                </jsp:forward>
                <%
            }
        %>
        
        <%@include file="footer.jsp" %>
    </body>
</html>