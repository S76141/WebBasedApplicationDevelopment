<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <%
            final double price=10.0;
            
            String cust_no=request.getParameter("custCode");
            String cust_type=request.getParameter("custType");
            
            int quantity=0;
            try{
                quantity= Integer.parseInt(request.getParameter("quantity"));
            }catch(Exception e){
                quantity=0;
            }
            
            double total=0;
            String message="";
            
            if(cust_type.equals("1")&&quantity>100){
                message="You're entitled to 10% discount";
                total= quantity*price*0.9;
            } else if (cust_type.equals("2") && quantity > 100) {
                message = "You're entitled to 25% discount";
                total = quantity * price * 0.75;
            } else {
                message = "You're not entitled to any discount";
                total = quantity * price;
            }
// Display customer type
            String custTypeDisplay = cust_type.equals("1") ?
            "Normal Customer" : "Privilege Customer";
        %>
        
        <h1>Customer Discount Result</h1>
        <div class="result-grid">
            <div class="result-box">
                <h3>Transaction Summary</h3>
                <div class="result-group">
                    <p>Customer Code:<%= cust_no %></p>
                    <p>Quantity:<%= quantity %></p>
                    <p>Customer Type:<%= custTypeDisplay %></p>
                    <p>Status:<%= message %></p>
                    <p>Total Amount:<%= total %></p>
                    <div class="btn-back">
                        <button onClick="history.back()">Back</button>
                    </div>
                </div>
            </div>
        </div>
        
    </body>
</html>
