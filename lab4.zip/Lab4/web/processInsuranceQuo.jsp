Z<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <h1>Insurance Quotation Result</h1>
        <div class="result-box">
            <%
                String icno=request.getParameter("icno");
                String name = request.getParameter("name");
                String coverage = request.getParameter("coveragetype");
                String ncdStr = request.getParameter("ncd");
                
                double price=0;
                double ncd=0;
                
                try{
                    price=Double.parseDouble(request.getParameter("marketprice"));
                    ncd=Double.parseDouble(ncdStr);
                }catch(Exception e){
                    price=0;
                    ncd=0;
                }
                
                double rate=0;
                String coverageDisplay="";
                
                if("Comprehensive".equals(coverage)){
                    rate=0.05;
                    coverageDisplay="Comprehensive";
                }else{
                    rate=0.03;
                    coverageDisplay="Third Party";
                }
                
                double insurance=price*rate;
                
                double discount=insurance*ncd;
                double afterNCD=insurance-discount;
                
                double sst=afterNCD*0.08;
                double finalAmount=afterNCD+sst;
            %>
            <div class="result-box">
                <div class="result-group">
                    <p>IC No: <%= icno %></p>
                    <p>Name: <%= name %></p>
                    <p>Market Price(RM): <%= price %></p>
                    <p>Coverage Type: <%= coverage %></p>
                    <p>NCD: <%= ncd %></p>
                </div>
                <div class="result-group">
                    <p>Base Insurance: <%= insurance %></p>
                    <p>NCD Discount: <%= discount %></p>
                    <p>After NCD: <%= afterNCD %></p>
                    <p>SST(8%): <%= sst %></p>
                    <p><b>Final Insurance Amount: <%= finalAmount %></b></p>
                
                    <button onClick="history.back()" >Back</button>
                <div>
            </div>
        </div>
    </body>
</html>
