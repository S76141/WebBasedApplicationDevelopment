<%-- 
    Document   : resultBmi
    Created on : May 12, 2026, 11:43:28 AM
    Author     : Huawei
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
<%@ include file="header.jsp" %>

<div class="content">
    <h2>Your BMI Result</h2>
    
    <%
        String bmi = request.getParameter("bmi");
        String category = request.getParameter("category");
        
        if (bmi != null && category != null) {
    %>
    
    <div style="text-align: center; padding: 30px;">
        <div style="font-size: 48px; color: #667eea; margin-bottom: 20px;">
            <%= bmi %>
        </div>
        <p style="font-size: 18px; color: #666;">Your BMI Score</p>
        
        <div style="margin-top: 30px; padding: 20px; background: #f8f9fa; border-radius: 10px;">
            <p style="font-size: 24px; font-weight: bold; 
                      <% if(category.equals("Underweight")) { %>color: #ff9800;<% } 
                         else if(category.equals("Normal")) { %>color: #4caf50;<% } 
                         else { %>color: #f44336;<% } %>">
                <%= category %>
            </p>
        </div>
        
        <div style="margin-top: 30px;">
            <h3>BMI Categories:</h3>
            <ul style="display: inline-block; text-align: left; margin-top: 15px;">
                <li><strong>Underweight:</strong> BMI less than 18.5</li>
                <li><strong>Normal:</strong> BMI between 18.5 and 25</li>
                <li><strong>Overweight:</strong> BMI greater than 25</li>
            </ul>
        </div>
        
        <div style="margin-top: 30px;">
            <a href="bmiCalculator.jsp" style="background: #667eea; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; display: inline-block;">
                Calculate Again
            </a>
        </div>
    </div>
    
    <%
        } else {
            response.sendRedirect("bmiCalculator.jsp");
        }
    %>
</div>

<%@ include file="footer.jsp" %>
    </body>
</html>
