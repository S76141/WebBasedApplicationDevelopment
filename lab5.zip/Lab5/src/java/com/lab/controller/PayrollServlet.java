package com.lab.controller;

import com.lab.bean.Employee;
import jakarta.servlet.RequestDispatcher;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.ArrayList;


public class PayrollServlet extends HttpServlet {
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        ArrayList<Employee> employeeList = new ArrayList<>();
        
        employeeList.add(new Employee("A01", "John", "Computer Science", 5500));
        employeeList.add(new Employee("A02", "Jimmy", "Cybersecurity", 4000));
        employeeList.add(new Employee("A03", "Jayden", "Front End Designer", 3000));
        employeeList.add(new Employee("A04", "Jason", "Database Developer", 2500));
        employeeList.add(new Employee("A05", "Jack", "Back End developer", 8000));
        employeeList.add(new Employee("A06", "Joo", "Full Stack Developer", 10000));
        
        request.setAttribute("employeelist", employeeList);
        
        RequestDispatcher rd = request.getRequestDispatcher("payroll_view.jsp");
        rd.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
