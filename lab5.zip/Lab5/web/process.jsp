<%-- 
    Document   : process
    Created on : Jun 7, 2026, 2:14:17 PM
    Author     : Huawei
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <h2>Calculator Result</h2>
        
        <jsp:useBean id="calc" class="com.lab.bean.CalculatorBean" />
        <jsp:setProperty name="calc" property="*" />
        <p>The sum of
            <jsp:getProperty name="calc" property="num1" /> and
            <jsp:getProperty name="calc" property="num2" /> is:
            <strong><jsp:getProperty name="calc" property="sum" /></strong>
        </p>
        
        <br><a href="calculator.html">Calculator Again</a>
    </body>
</html>