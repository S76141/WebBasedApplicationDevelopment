<%-- 
    Document   : task1
    Created on : May 13, 2026, 9:02:32 AM
    Author     : Huawei
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="com.lab.bean.StudentBean"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Task 1: Scriptlet& Bean</title>
    </head>
    <body>
        <h2>Student Information (Using Scriptlet)</h2>
        
        <% 
            StudentBean student=new StudentBean();
            student.setName("Ahmad Ali");
            student.setMatricNo("S123456");
        %>
        
        <p><strong>Name:</strong><%= student.getName() %></p>
        <p><strong>Matric No:</strong><%= student.getMatricNo() %></p>
    </body>
</html>
